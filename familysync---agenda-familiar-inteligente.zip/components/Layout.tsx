
import React, { useState, useEffect } from 'react';
import { Calendar, List, Database, Users, Download, Share2, Github, Globe, CheckCircle2, AlertCircle } from 'lucide-react';
import { supabase } from '../services/supabaseService';

interface LayoutProps {
  children: React.ReactNode;
  activeView: 'calendar' | 'list' | 'import';
  setActiveView: (view: 'calendar' | 'list' | 'import') => void;
}

export const Layout: React.FC<LayoutProps> = ({ children, activeView, setActiveView }) => {
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);
  const [dbStatus, setDbStatus] = useState<'online' | 'offline' | 'checking'>('checking');

  useEffect(() => {
    const checkConn = async () => {
      try {
        const { error } = await supabase.from('events').select('id').limit(1);
        setDbStatus(error ? 'offline' : 'online');
      } catch {
        setDbStatus('offline');
      }
    };
    checkConn();

    window.addEventListener('beforeinstallprompt', (e) => {
      e.preventDefault();
      setDeferredPrompt(e);
    });
  }, []);

  const handleInstall = async () => {
    if (!deferredPrompt) return;
    deferredPrompt.prompt();
    const { outcome } = await deferredPrompt.userChoice;
    if (outcome === 'accepted') setDeferredPrompt(null);
  };

  const handleShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: 'FamilySync',
          text: 'Accede a nuestra agenda familiar',
          url: window.location.href,
        });
      } catch (err) { console.error(err); }
    } else {
      await navigator.clipboard.writeText(window.location.href);
      alert('¡Enlace copiado! Ya puedes pegarlo en WhatsApp.');
    }
  };

  return (
    <div className="flex h-screen bg-slate-50">
      {/* Sidebar */}
      <aside className="w-20 md:w-64 bg-white border-r border-slate-200 flex flex-col transition-all duration-300 shadow-sm z-20">
        <div className="p-6 flex items-center gap-3">
          <div className="w-10 h-10 bg-indigo-600 rounded-xl flex items-center justify-center shadow-lg shadow-indigo-200 shrink-0">
            <Users className="text-white w-6 h-6" />
          </div>
          <span className="font-bold text-xl hidden md:block tracking-tight text-slate-800">FamilySync</span>
        </div>

        <nav className="flex-1 px-4 py-6 space-y-2">
          <button
            onClick={() => setActiveView('calendar')}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all ${
              activeView === 'calendar' ? 'bg-indigo-50 text-indigo-600 font-bold' : 'text-slate-500 hover:bg-slate-50'
            }`}
          >
            <Calendar className="w-5 h-5" />
            <span className="hidden md:block">Calendario</span>
          </button>
          <button
            onClick={() => setActiveView('list')}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all ${
              activeView === 'list' ? 'bg-indigo-50 text-indigo-600 font-bold' : 'text-slate-500 hover:bg-slate-50'
            }`}
          >
            <List className="w-5 h-5" />
            <span className="hidden md:block">Agenda</span>
          </button>
          <button
            onClick={() => setActiveView('import')}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all ${
              activeView === 'import' ? 'bg-indigo-50 text-indigo-600 font-bold' : 'text-slate-500 hover:bg-slate-50'
            }`}
          >
            <Database className="w-5 h-5" />
            <span className="hidden md:block">Estado Cloud</span>
          </button>
        </nav>

        <div className="px-4 py-4 space-y-1">
          <button
            onClick={handleShare}
            className="w-full flex items-center gap-3 px-4 py-2 rounded-lg text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 transition-all text-xs font-bold uppercase"
          >
            <Share2 className="w-4 h-4" />
            <span className="hidden md:block">Compartir App</span>
          </button>

          <a 
            href="https://github.com/Csanchezflor-celula" 
            target="_blank" 
            rel="noopener noreferrer"
            className="w-full flex items-center gap-3 px-4 py-2 rounded-lg text-slate-400 hover:text-slate-800 hover:bg-slate-50 transition-all text-xs font-bold uppercase"
          >
            <Github className="w-4 h-4" />
            <span className="hidden md:block">Ver mi Código</span>
          </a>

          {deferredPrompt && (
            <button
              onClick={handleInstall}
              className="w-full flex items-center gap-3 px-4 py-3 mt-2 rounded-xl bg-indigo-600 text-white shadow-lg shadow-indigo-100 hover:bg-indigo-700 transition-all"
            >
              <Download className="w-5 h-5" />
              <span className="hidden md:block text-xs font-black uppercase tracking-tight">Instalar App</span>
            </button>
          )}
        </div>

        <div className="p-4 border-t border-slate-100">
          <div className="flex flex-col gap-2 p-3 bg-slate-50 rounded-2xl">
            <div className="flex items-center gap-2">
              <div className={`w-2 h-2 rounded-full ${dbStatus === 'online' ? 'bg-emerald-500 shadow-[0_0_8px_rgba(16,185,129,0.5)]' : 'bg-rose-500'}`} />
              <span className="text-[10px] font-black text-slate-500 uppercase tracking-tighter">
                {dbStatus === 'online' ? 'Base de datos OK' : 'Conectando...'}
              </span>
            </div>
            <div className="flex items-center gap-3">
              <img src="https://picsum.photos/seed/family_avatar/100" className="w-7 h-7 rounded-full border border-white shadow-sm" alt="Family" />
              <p className="text-[11px] font-black text-slate-800 truncate hidden md:block">C. Sánchez-Flor</p>
            </div>
          </div>
        </div>
      </aside>

      <main className="flex-1 overflow-auto bg-slate-50 relative">
        <div className="max-w-6xl mx-auto p-4 md:p-8 pb-24">
          {children}
        </div>
      </main>
    </div>
  );
};
