
import React, { useState } from 'react';
import { Sparkles, Loader2, Plus } from 'lucide-react';
import { geminiService } from '../services/geminiService';
import { AgendaEvent } from '../types';
import { FAMILY_MEMBERS } from '../constants';

interface SmartInputProps {
  onEventParsed: (event: AgendaEvent) => void;
}

export const SmartInput: React.FC<SmartInputProps> = ({ onEventParsed }) => {
  const [text, setText] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!text.trim() || isLoading) return;

    setIsLoading(true);
    try {
      const parsed = await geminiService.parseNaturalLanguage(text);
      
      // Match member by name if possible, default to first member (All)
      const member = FAMILY_MEMBERS.find(m => 
        parsed.memberName?.toLowerCase().includes(m.name.toLowerCase())
      ) || FAMILY_MEMBERS[0];

      const newEvent: AgendaEvent = {
        id: crypto.randomUUID(),
        title: parsed.title || 'Nuevo Evento',
        description: parsed.description || '',
        date: parsed.date || new Date().toISOString().split('T')[0],
        startTime: parsed.startTime,
        endTime: parsed.endTime,
        memberId: member.id,
        category: parsed.category || 'Otro',
        isReminder: !!parsed.isReminder
      };

      onEventParsed(newEvent);
      setText('');
    } catch (error) {
      console.error("Error parsing language:", error);
      alert("No pude entender bien el evento. Intenta ser más específico o usa el formulario.");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="relative mb-8">
      <form onSubmit={handleSubmit} className="relative group">
        <div className="absolute inset-y-0 left-5 flex items-center pointer-events-none">
          <Sparkles className="h-5 w-5 text-indigo-400 group-focus-within:text-indigo-600 transition-colors" />
        </div>
        <input
          type="text"
          value={text}
          onChange={(e) => setText(e.target.value)}
          placeholder="Escribe algo como: 'Cita dentista Alex martes a las 10:00'..."
          className="block w-full pl-12 pr-32 py-5 bg-white border border-slate-200 rounded-2xl shadow-sm focus:ring-4 focus:ring-indigo-100 focus:border-indigo-400 transition-all text-lg placeholder:text-slate-400"
          disabled={isLoading}
        />
        <div className="absolute inset-y-2 right-2 flex gap-2">
          <button
            type="submit"
            disabled={isLoading || !text.trim()}
            className="flex items-center gap-2 px-6 bg-indigo-600 text-white font-bold rounded-xl hover:bg-indigo-700 disabled:opacity-50 transition-all active:scale-95"
          >
            {isLoading ? (
              <Loader2 className="w-5 h-5 animate-spin" />
            ) : (
              <>
                <Plus className="w-5 h-5" />
                <span className="hidden sm:inline">Añadir</span>
              </>
            )}
          </button>
        </div>
      </form>
      <p className="mt-2 text-xs text-slate-400 flex items-center gap-1 px-2">
        <span className="font-bold text-indigo-500 uppercase">Tip:</span> La IA detecta automáticamente quién, qué y cuándo.
      </p>
    </div>
  );
};
