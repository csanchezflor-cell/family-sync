
import React from 'react';
import { AgendaEvent } from '../types';
import { FAMILY_MEMBERS, CATEGORY_COLORS } from '../constants';
import { Clock, User, Tag, Trash2, Calendar as CalendarIcon } from 'lucide-react';

interface EventCardProps {
  event: AgendaEvent;
  onDelete: (id: string) => void;
}

export const EventCard: React.FC<EventCardProps> = ({ event, onDelete }) => {
  const member = FAMILY_MEMBERS.find(m => m.id === event.memberId) || FAMILY_MEMBERS[0];
  
  // Formatear la fecha: "Mar, 27 Ene"
  const formattedDate = new Date(event.date).toLocaleDateString('es-ES', {
    weekday: 'short',
    day: 'numeric',
    month: 'short'
  });

  return (
    <div className="group relative bg-white border border-slate-200 rounded-3xl p-6 shadow-sm hover:shadow-xl transition-all duration-300 hover:-translate-y-1">
      <div className="flex justify-between items-start mb-4">
        <span className={`px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider border ${CATEGORY_COLORS[event.category]}`}>
          {event.category}
        </span>
        <button 
          onClick={() => onDelete(event.id)}
          className="text-slate-300 hover:text-red-500 transition-colors p-1 bg-slate-50 rounded-lg hover:bg-red-50"
        >
          <Trash2 className="w-4 h-4" />
        </button>
      </div>

      <div className="flex items-center gap-2 mb-2">
        <CalendarIcon className="w-3.5 h-3.5 text-indigo-500" />
        <span className="text-xs font-black text-indigo-600 uppercase tracking-tighter">{formattedDate}</span>
      </div>

      <h3 className="text-xl font-black text-slate-800 mb-2 leading-tight group-hover:text-indigo-600 transition-colors">{event.title}</h3>
      
      {event.description && (
        <p className="text-sm text-slate-500 mb-6 line-clamp-2 italic">"{event.description}"</p>
      )}

      <div className="pt-4 border-t border-slate-50 space-y-3">
        <div className="flex items-center gap-3 text-sm text-slate-600">
          <div className="p-1.5 bg-slate-100 rounded-lg">
            <Clock className="w-4 h-4 text-slate-500" />
          </div>
          <span className="font-semibold">{event.isReminder ? 'Todo el día' : `${event.startTime || '--:--'} - ${event.endTime || '--:--'}`}</span>
        </div>
        <div className="flex items-center gap-3 text-sm text-slate-600">
          <img src={member.avatar} className="w-6 h-6 rounded-full border border-white shadow-sm" alt={member.name} />
          <span className="font-bold text-slate-700">{member.name}</span>
        </div>
      </div>
    </div>
  );
};
