
import React from 'react';
import { AgendaEvent } from '../types';
import { EventCard } from './EventCard';
import { X, Calendar as CalendarIcon } from 'lucide-react';

interface DayModalProps {
  date: string;
  events: AgendaEvent[];
  onClose: () => void;
  onDelete: (id: string) => void;
}

export const DayModal: React.FC<DayModalProps> = ({ date, events, onClose, onDelete }) => {
  // Formatear la fecha para mostrar: "Martes, 27 de Enero"
  const formattedDate = new Date(date).toLocaleDateString('es-ES', {
    weekday: 'long',
    day: 'numeric',
    month: 'long'
  });

  return (
    <div className="fixed inset-0 z-[110] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-slate-50 rounded-[2.5rem] w-full max-w-4xl max-h-[90vh] overflow-hidden shadow-2xl flex flex-col animate-in zoom-in duration-300">
        {/* Header del Modal */}
        <div className="p-8 bg-white border-b border-slate-100 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 bg-indigo-100 text-indigo-600 rounded-2xl flex items-center justify-center">
              <CalendarIcon className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-2xl font-black text-slate-800 capitalize">{formattedDate}</h3>
              <p className="text-slate-500 font-medium">{events.length} {events.length === 1 ? 'evento' : 'eventos'} programados</p>
            </div>
          </div>
          <button 
            onClick={onClose}
            className="p-3 bg-slate-100 text-slate-500 rounded-2xl hover:bg-slate-200 transition-colors"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Cuerpo del Modal */}
        <div className="flex-1 overflow-y-auto p-8">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {events.map(event => (
              <EventCard key={event.id} event={event} onDelete={onDelete} />
            ))}
          </div>
        </div>

        {/* Footer del Modal */}
        <div className="p-6 bg-white border-t border-slate-100 text-center">
          <button 
            onClick={onClose}
            className="px-8 py-3 bg-slate-800 text-white font-bold rounded-2xl hover:bg-slate-900 transition-all active:scale-95"
          >
            Cerrar Ventana
          </button>
        </div>
      </div>
    </div>
  );
};
