
import React, { useState } from 'react';
import { 
  FileText, Download, Loader2, CheckCircle, AlertTriangle, 
  Save, Rocket, ShieldCheck, Github, Globe, ExternalLink, 
  Copy, Check, ArrowRight, Zap, Play, Sparkles, Star, Settings2, RefreshCw, Key, FilterX
} from 'lucide-react';
import { geminiService } from '../services/geminiService';
import { AgendaEvent } from '../types';
import { FAMILY_MEMBERS } from '../constants';

interface ImportDataProps {
  onImportComplete: (events: AgendaEvent[]) => void;
  events: AgendaEvent[];
}

export const ImportData: React.FC<ImportDataProps> = ({ onImportComplete, events }) => {
  const [chatHistory, setChatHistory] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [copied, setCopied] = useState(false);

  const downloadBackup = () => {
    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(events, null, 2));
    const downloadAnchorNode = document.createElement('a');
    downloadAnchorNode.setAttribute("href", dataStr);
    downloadAnchorNode.setAttribute("download", `respaldo_agenda_${new Date().toISOString().split('T')[0]}.json`);
    document.body.appendChild(downloadAnchorNode);
    downloadAnchorNode.click();
    downloadAnchorNode.remove();
  };

  const handleImport = async () => {
    if (!chatHistory.trim() || isLoading) return;
    setIsLoading(true);
    try {
      const parsedEvents = await geminiService.importFromChatHistory(chatHistory);
      const newEvents: AgendaEvent[] = parsedEvents.map(p => {
        const member = FAMILY_MEMBERS.find(m => p.memberName?.toLowerCase().includes(m.name.toLowerCase())) || FAMILY_MEMBERS[0];
        return {
          id: crypto.randomUUID(),
          title: p.title || 'Evento Importado',
          description: p.description || '',
          date: p.date || new Date().toISOString().split('T')[0],
          startTime: p.startTime || '00:00',
          endTime: p.endTime,
          memberId: member.id,
          category: p.category || 'Otro',
          isReminder: !!p.isReminder
        };
      });
      onImportComplete(newEvents);
      setChatHistory('');
    } catch (error) {
      console.error(error);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="max-w-5xl mx-auto space-y-10 pb-32">
      {/* Vercel Empty Deployments Support */}
      <div className="bg-gradient-to-br from-amber-500 to-orange-600 rounded-[3rem] p-8 md:p-12 text-white shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 right-0 p-8 opacity-10">
          <FilterX className="w-64 h-64" />
        </div>
        
        <div className="relative z-10 flex flex-col md:flex-row items-center gap-10">
          <div className="w-24 h-24 bg-white/20 backdrop-blur-xl border border-white/30 rounded-3xl flex items-center justify-center shadow-2xl shrink-0">
            <RefreshCw className="w-12 h-12 text-white animate-spin-slow" />
          </div>
          
          <div className="text-center md:text-left space-y-4">
            <h2 className="text-4xl font-black tracking-tight leading-tight">¿Lista de despliegues vacía?</h2>
            <p className="text-amber-50 font-medium text-lg max-w-xl">
              No te preocupes, esto pasa cuando Vercel está esperando la primera "chispa" o tienes un filtro activado.
            </p>
            <button 
              onClick={() => { navigator.clipboard.writeText('API_KEY'); setCopied(true); setTimeout(() => setCopied(false), 2000); }}
              className="bg-white text-orange-600 px-8 py-4 rounded-2xl font-black text-sm flex items-center gap-2 hover:bg-orange-50 transition-all shadow-xl active:scale-95"
            >
              {copied ? <Check className="w-5 h-5" /> : <Copy className="w-5 h-5" />}
              Copiar "API_KEY" para el paso 2
            </button>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-5 gap-8">
        <div className="lg:col-span-3 space-y-8">
          <div className="bg-white p-10 rounded-[3rem] border border-slate-200 shadow-sm space-y-8">
            <h3 className="font-black text-slate-800 text-2xl tracking-tight flex items-center gap-3">
              <Rocket className="w-6 h-6 text-orange-500" />
              Cómo forzar el primer despliegue
            </h3>
            
            <div className="space-y-6">
              {/* Step 1 */}
              <div className="flex gap-6 items-start p-6 bg-slate-50 rounded-3xl border border-slate-100">
                <div className="w-10 h-10 rounded-2xl bg-white shadow-sm flex items-center justify-center font-black text-orange-600 shrink-0">1</div>
                <div className="space-y-1">
                  <p className="font-black text-slate-800">Pulsa en "Filtros claros"</p>
                  <p className="text-sm text-slate-500">En tu pantalla de Vercel, debajo del texto de "Sin resultados", pulsa el enlace azul para ver si aparecen intentos previos.</p>
                </div>
              </div>

              {/* Step 2 */}
              <div className="flex gap-6 items-start p-6 bg-slate-50 rounded-3xl border border-slate-100">
                <div className="w-10 h-10 rounded-2xl bg-white shadow-sm flex items-center justify-center font-black text-orange-600 shrink-0">2</div>
                <div className="space-y-1">
                  <p className="font-black text-slate-800">Configura la llave (OBLIGATORIO)</p>
                  <p className="text-sm text-slate-500">Ve a <b>Configuración</b> → <b>Variables de entorno</b>. Añade la <code>API_KEY</code>. Sin esto, Vercel cancelará cualquier intento.</p>
                </div>
              </div>

              {/* Step 3 */}
              <div className="flex gap-6 items-start p-6 bg-orange-600 text-white rounded-3xl shadow-xl shadow-orange-100">
                <div className="w-10 h-10 rounded-2xl bg-white/20 backdrop-blur-md flex items-center justify-center font-black text-white shrink-0">3</div>
                <div className="space-y-1">
                  <p className="font-black">Dispara el proceso</p>
                  <p className="text-sm text-orange-100">Si sigue vacío, ve a la pestaña <b>Resumen</b> y busca el botón azul <b>"Deploy"</b>. Si no sale, haz un pequeño cambio en cualquier archivo de tu GitHub y guárdalo.</p>
                </div>
              </div>
            </div>
          </div>

          <div className="bg-white p-10 rounded-[3rem] border border-slate-200 shadow-sm space-y-8">
            <div className="flex items-center gap-3">
              <Sparkles className="w-6 h-6 text-orange-500" />
              <h3 className="font-black text-slate-800 text-xl tracking-tight">Probador de IA Local</h3>
            </div>
            <textarea
              value={chatHistory}
              onChange={(e) => setChatHistory(e.target.value)}
              rows={4}
              className="w-full p-6 bg-slate-50 border border-slate-200 rounded-[2rem] focus:ring-4 focus:ring-orange-100 outline-none text-slate-700 font-medium text-sm transition-all"
              placeholder="Pega texto aquí para probar cuando la App esté lista..."
            ></textarea>
            <button
              onClick={handleImport}
              disabled={isLoading || !chatHistory.trim()}
              className="w-full py-5 bg-orange-600 text-white font-black rounded-3xl hover:bg-orange-700 transition-all active:scale-95 shadow-xl flex items-center justify-center gap-3"
            >
              {isLoading ? <Loader2 className="w-6 h-6 animate-spin" /> : <Download className="w-6 h-6" />}
              Importar (Solo tras desplegar)
            </button>
          </div>
        </div>

        <div className="lg:col-span-2 space-y-6">
          <div className="bg-white border-2 border-orange-100 p-8 rounded-[3rem] space-y-6">
            <h4 className="font-black text-orange-600">Ayuda Rápida</h4>
            <div className="space-y-4">
              <div className="p-4 bg-orange-50 rounded-2xl">
                <p className="text-[10px] font-black text-orange-800 uppercase mb-1">Error común</p>
                <p className="text-xs text-orange-700 font-medium">Si el repositorio de GitHub está vacío, Vercel no tiene nada que mostrar. Asegúrate de que has subido los archivos.</p>
              </div>
              <a 
                href="https://aistudio.google.com/app/apikey" 
                target="_blank" 
                className="flex items-center justify-between w-full p-4 bg-slate-900 text-white rounded-2xl hover:bg-black transition-all"
              >
                <span className="text-xs font-black">Obtener mi API KEY</span>
                <ExternalLink className="w-4 h-4" />
              </a>
            </div>
          </div>

          <button 
            onClick={downloadBackup}
            className="w-full py-5 border-2 border-dashed border-slate-300 rounded-[2.5rem] text-slate-400 font-black hover:border-slate-400 hover:text-slate-500 transition-all flex items-center justify-center gap-2"
          >
            <Save className="w-5 h-5" />
            Bajar Respaldo Local
          </button>
        </div>
      </div>
      <style>{`
        @keyframes spin-slow {
          from { transform: rotate(0deg); }
          to { transform: rotate(360deg); }
        }
        .animate-spin-slow {
          animation: spin-slow 8s linear infinite;
        }
      `}</style>
    </div>
  );
};
