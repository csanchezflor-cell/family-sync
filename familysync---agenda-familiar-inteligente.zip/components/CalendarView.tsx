
import React, { useState } from 'react';
import { AgendaEvent } from '../types';
import { ChevronLeft, ChevronRight, LayoutGrid, List } from 'lucide-react';

interface CalendarViewProps {
  events: AgendaEvent[];
  onDateClick: (date: string) => void;
}

export const CalendarView: React.FC<CalendarViewProps> = ({ events, onDateClick }) => {
  const [currentDate, setCurrentDate] = useState(new Date());
  const [viewMode, setViewMode] = useState<'month' | 'week'>('month');

  const year = currentDate.getFullYear();
  const month = currentDate.getMonth();

  const prev = () => {
    const d = new Date(currentDate);
    if (viewMode === 'month') d.setMonth(month - 1);
    else d.setDate(d.getDate() - 7);
    setCurrentDate(d);
  };

  const next = () => {
    const d = new Date(currentDate);
    if (viewMode === 'month') d.setMonth(month + 1);
    else d.setDate(d.getDate() + 7);
    setCurrentDate(d);
  };

  const getWeekDays = () => {
    const d = new Date(currentDate);
    const day = d.getDay();
    const diff = d.getDate() - day + (day === 0 ? -6 : 1);
    const monday = new Date(d.setDate(diff));
    return Array.from({ length: 7 }, (_, i) => {
      const day = new Date(monday);
      day.setDate(monday.getDate() + i);
      return day;
    });
  };

  const monthNames = ["Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio", "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"];

  return (
    <div className="bg-white rounded-[2.5rem] border border-slate-200 shadow-xl overflow-hidden">
      <div className="flex flex-col sm:flex-row items-center justify-between p-6 border-b border-slate-100 bg-slate-50/50 gap-4">
        <div className="flex items-center gap-4">
          <h2 className="text-2xl font-black text-slate-800">
            {viewMode === 'month' ? monthNames[month] : 'Semana'} <span className="text-indigo-600">{year}</span>
          </h2>
        </div>
        
        <div className="flex items-center gap-3">
          <div className="flex bg-white p-1 rounded-xl border border-slate-200 shadow-sm mr-2">
            <button onClick={() => setViewMode('month')} className={`p-2 rounded-lg transition-all ${viewMode === 'month' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:bg-slate-50'}`}><LayoutGrid className="w-5 h-5" /></button>
            <button onClick={() => setViewMode('week')} className={`p-2 rounded-lg transition-all ${viewMode === 'week' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:bg-slate-50'}`}><List className="w-5 h-5" /></button>
          </div>

          <div className="flex gap-2 bg-white p-1 rounded-xl border border-slate-200 shadow-sm">
            <button onClick={prev} className="p-2 hover:bg-slate-50 rounded-lg text-slate-600"><ChevronLeft className="w-5 h-5" /></button>
            <button onClick={() => setCurrentDate(new Date())} className="px-3 text-xs font-bold text-indigo-600">Hoy</button>
            <button onClick={next} className="p-2 hover:bg-slate-50 rounded-lg text-slate-600"><ChevronRight className="w-5 h-5" /></button>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-7 text-center border-b border-slate-100 bg-slate-50/30">
        {['Lun', 'Mar', 'Mié', 'Jue', 'Vie', 'Sáb', 'Dom'].map(day => (
          <div key={day} className="py-3 text-[10px] md:text-xs font-bold text-slate-400 uppercase tracking-widest">{day}</div>
        ))}
      </div>

      <div className="grid grid-cols-7">
        {viewMode === 'month' ? (
          <>
            {Array.from({ length: (new Date(year, month, 1).getDay() === 0 ? 6 : new Date(year, month, 1).getDay() - 1) }).map((_, i) => (
              <div key={`empty-${i}`} className="h-24 sm:h-32 border-b border-r border-slate-50 bg-slate-50/5"></div>
            ))}
            {Array.from({ length: new Date(year, month + 1, 0).getDate() }).map((_, i) => {
              const d = i + 1;
              const dateStr = `${year}-${String(month + 1).padStart(2, '0')}-${String(d).padStart(2, '0')}`;
              const dayEvents = events.filter(e => e.date === dateStr);
              const isToday = new Date().toDateString() === new Date(year, month, d).toDateString();
              return (
                <div key={d} onClick={() => onDateClick(dateStr)} className={`h-24 sm:h-32 border-b border-r border-slate-100 p-2 hover:bg-indigo-50/30 cursor-pointer relative ${isToday ? 'bg-indigo-50/20' : ''}`}>
                  <span className={`text-xs font-bold inline-flex items-center justify-center w-6 h-6 rounded-full mb-1 ${isToday ? 'bg-indigo-600 text-white' : 'text-slate-700'}`}>{d}</span>
                  <div className="space-y-1">
                    {dayEvents.slice(0, 2).map(e => (
                      <div key={e.id} className="text-[8px] px-1 py-0.5 rounded bg-white border border-slate-100 text-slate-600 truncate shadow-sm">
                        {e.title}
                      </div>
                    ))}
                    {dayEvents.length > 2 && <div className="text-[8px] text-slate-400 font-bold">+{dayEvents.length - 2}</div>}
                  </div>
                </div>
              );
            })}
          </>
        ) : (
          getWeekDays().map((date, i) => {
            const dateStr = date.toISOString().split('T')[0];
            const dayEvents = events.filter(e => e.date === dateStr);
            const isToday = new Date().toDateString() === date.toDateString();
            return (
              <div key={i} onClick={() => onDateClick(dateStr)} className={`h-80 sm:h-[400px] border-r border-slate-100 p-2 hover:bg-indigo-50/30 cursor-pointer relative ${isToday ? 'bg-indigo-50/20' : ''}`}>
                <div className="text-center mb-3">
                  <span className={`text-sm font-black inline-flex items-center justify-center w-8 h-8 rounded-lg ${isToday ? 'bg-indigo-600 text-white shadow-lg' : 'bg-slate-100 text-slate-700'}`}>{date.getDate()}</span>
                </div>
                <div className="space-y-2 overflow-y-auto h-[90%] no-scrollbar">
                  {dayEvents.sort((a,b) => (a.startTime||'').localeCompare(b.startTime||'')).map(e => (
                    <div key={e.id} className="text-[10px] p-2 rounded-xl bg-white border border-slate-200 shadow-sm leading-tight">
                      <div className="font-bold text-slate-800 line-clamp-2">{e.startTime} - {e.title}</div>
                      <div className="mt-1 text-[8px] text-indigo-500 font-bold uppercase">{e.memberId}</div>
                    </div>
                  ))}
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
