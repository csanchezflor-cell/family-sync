
import { createClient } from '@supabase/supabase-js';
import { AgendaEvent } from '../types';

const supabaseUrl = 'https://qgultwfwujrkowneuecd.supabase.co';
const supabaseAnonKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InFndWx0d2Z3dWpya293bmV1ZWNkIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjgyMzE4OTEsImV4cCI6MjA4MzgwNzg5MX0.igcmjRfnT8cKkuA5H0tTB1Mf0k2DjQtWcObloa2E57o'; 

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

const cleanTime = (timeStr?: string): string => {
  if (!timeStr || timeStr === 'undefined' || timeStr === 'null' || timeStr.trim() === '') return '00:00';
  const match = timeStr.match(/(\d{1,2}:\d{2})/);
  return match ? match[1].padStart(5, '0') : '00:00';
};

const cleanDate = (dateStr?: string): string => {
  if (!dateStr || dateStr.trim() === '') return new Date().toISOString().split('T')[0];
  const match = dateStr.match(/(\d{4}-\d{2}-\d{2})/);
  return match ? match[1] : new Date().toISOString().split('T')[0];
};

export const supabaseService = {
  mapFromDb(dbEvent: any): AgendaEvent | null {
    try {
      if (!dbEvent.start_time) return null;
      const startDate = new Date(dbEvent.start_time);
      return {
        id: dbEvent.id,
        title: dbEvent.title || 'Sin título',
        description: dbEvent.description || '',
        date: startDate.toISOString().split('T')[0],
        startTime: startDate.toLocaleTimeString('es-ES', { hour: '2-digit', minute: '2-digit', hour12: false }),
        endTime: dbEvent.end_time ? new Date(dbEvent.end_time).toLocaleTimeString('es-ES', { hour: '2-digit', minute: '2-digit', hour12: false }) : undefined,
        category: dbEvent.category || 'Otro',
        memberId: dbEvent.location || 'all', 
        isReminder: false
      };
    } catch (e) {
      return null;
    }
  },

  mapToDb(event: AgendaEvent) {
    const date = cleanDate(event.date);
    const startTime = cleanTime(event.startTime);
    let endTime = cleanTime(event.endTime);
    
    if (endTime === '00:00' && startTime === '00:00') {
      endTime = '23:59';
    } else if (endTime === '00:00') {
      endTime = startTime;
    }

    return {
      title: event.title || 'Evento sin título',
      description: event.description || '',
      start_time: `${date}T${startTime}:00`,
      end_time: `${date}T${endTime}:00`,
      category: event.category || 'Otro',
      location: event.memberId || 'all',
      status: 'confirmed'
      // IMPORTANTE: Quitamos user_id para que no choque con la restricción de clave foránea
    };
  },

  async fetchEvents(): Promise<AgendaEvent[]> {
    try {
      const { data, error } = await supabase
        .from('events')
        .select('*')
        .order('start_time', { ascending: true });

      if (error) throw error;
      return (data || []).map(this.mapFromDb).filter((e): e is AgendaEvent => e !== null);
    } catch (err: any) {
      console.error("Error crítico en fetchEvents:", err.message);
      return [];
    }
  },

  async saveEvent(event: AgendaEvent): Promise<{success: boolean, error?: string}> {
    const { error } = await supabase
      .from('events')
      .insert([this.mapToDb(event)]);

    if (error) return { success: false, error: error.message };
    return { success: true };
  },

  async saveBulkEvents(events: AgendaEvent[]): Promise<{success: boolean, count: number, error?: string}> {
    const dbEvents = events
      .filter(e => e.title || e.description)
      .map(e => this.mapToDb(e));

    if (dbEvents.length === 0) return { success: true, count: 0 };

    const { data, error } = await supabase
      .from('events')
      .insert(dbEvents)
      .select();

    if (error) return { success: false, count: 0, error: error.message };
    return { success: true, count: data?.length || 0 };
  },

  async deleteEvent(id: string): Promise<boolean> {
    const { error } = await supabase.from('events').delete().eq('id', id);
    return !error;
  }
};
