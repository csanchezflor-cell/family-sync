
import { GoogleGenAI, Type } from "@google/genai";
import { AgendaEvent } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const agendaEventSchema = {
  type: Type.OBJECT,
  properties: {
    title: { type: Type.STRING, description: "Título breve y descriptivo." },
    description: { type: Type.STRING, description: "Notas adicionales relevantes." },
    date: { type: Type.STRING, description: "Fecha ISO YYYY-MM-DD." },
    startTime: { type: Type.STRING, description: "HH:mm (24h)." },
    endTime: { type: Type.STRING, description: "HH:mm (24h)." },
    category: { type: Type.STRING, description: "Salud, Colegio, Ocio, Trabajo, Hogar o Otro." },
    member: { type: Type.STRING, description: "Nombre (Papá, Mamá, Ahsoka o Toda la familia)." },
    isReminder: { type: Type.BOOLEAN, description: "True si no tiene hora específica." }
  },
  required: ["title", "date", "category", "member", "startTime"]
};

export const geminiService = {
  async parseNaturalLanguage(text: string): Promise<Partial<AgendaEvent> & { memberName: string }> {
    const today = new Date().toISOString().split('T')[0];
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `Fecha de referencia (Hoy): ${today}. 
      Analiza: "${text}". 
      Si dice "mañana", usa la fecha de mañana. Si dice un día de la semana, usa el siguiente disponible. 
      Sé muy preciso con el miembro de la familia mencionado.`,
      config: {
        responseMimeType: "application/json",
        responseSchema: agendaEventSchema
      }
    });
    const data = JSON.parse(response.text);
    return { ...data, memberName: data.member };
  },

  async importFromChatHistory(history: string): Promise<Array<Partial<AgendaEvent> & { memberName: string }>> {
    const today = new Date().toISOString().split('T')[0];
    const response = await ai.models.generateContent({
      model: "gemini-3-pro-preview",
      contents: `ACTÚA COMO UN EXTRACTOR DE DATOS QUIRÚRGICO.
      Extrae eventos del historial de chat basándote en la fecha de HOY: ${today}.
      
      REGLAS CRÍTICAS DE CALIDAD:
      1. NO INVENTES eventos recurrentes (ej: entrenamientos semanales) si el chat no dice explícitamente "todos los lunes" o "cada semana".
      2. Si un evento se menciona en pasado y no tiene fecha futura clara, IGNÓRALO.
      3. No dupliques eventos que se discuten varias veces; usa solo la información más reciente.
      
      Chat:\n${history}`,
      config: {
        responseMimeType: "application/json",
        responseSchema: { type: Type.ARRAY, items: agendaEventSchema },
        thinkingConfig: { thinkingBudget: 2000 }
      }
    });
    const parsed = JSON.parse(response.text);
    return parsed.map((p: any) => ({ ...p, memberName: p.member }));
  }
};
